#include<stdio.h>
int main(){
	int i,j,ans;
	int n;
	for(i=11;i<=20;i++){
	printf("\n\t");
	for(j=1;j<=10;j++){
		ans=j*i;
	printf("%d\t",ans);
	}
	printf("\n");
	}
}